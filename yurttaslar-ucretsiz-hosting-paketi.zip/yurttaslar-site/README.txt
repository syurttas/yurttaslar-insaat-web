YURTTAŞLAR İNŞAAT YAPI DEKORASYON — ÜCRETSİZ STATİK YAYIN

Bu klasördeki index.html, statik hosting için ana sayfa dosyasıdır.

GitHub Pages ile yayınlama:
1. https://github.com adresinde hesap açın veya giriş yapın.
2. Sağ üstte + > New repository seçin.
3. Repository name alanına yurttaslar-insaat-web yazın ve Public seçin.
4. Create repository deyin.
5. Add file > Upload files ile index.html dosyasını yükleyin ve Commit changes deyin.
6. Repository > Settings > Pages bölümünü açın.
7. Build and deployment altında Deploy from a branch seçin.
8. Branch: main, folder: /(root) seçip Save deyin.
9. Birkaç dakika sonra aynı Pages bölümünde yayın adresi görünür.

Notlar:
- Bu yöntem statik HTML sitesi içindir; sunucu veya veritabanı gerektirmez.
- Site yayınlanmadan önce telefon, e-posta ve WhatsApp bağlantılarını test edin.
- Özel alan adı sonradan Pages ayarlarından bağlanabilir; alan adının kendisi genellikle ücretlidir.
